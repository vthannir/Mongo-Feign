package com.spring.mongo.api.controller;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.spring.mongo.api.model.User;
import com.spring.mongo.api.repository.UserRepository;
import com.spring.mongo.api.controller.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired	
	private UserRepository userRepo;

	 
		
	// @RequestMapping(value = "/", method = RequestMethod.GET)
	 @GetMapping("/abc")
	public List<User> getAllUser() {
	 return userRepo.findAll();
	 }
	 @GetMapping("/{id}")
	 public User getUserByid(@PathVariable("id") ObjectId id) {
	   return userRepo.findByid(id);
	 }
	 
//	 @PostMapping("/name")
//	 public User getUserByName(@RequestBody User name) {
//		 System.out.println("2nd......caleed/........");
//		 System.out.println("Input..."+name);
//		 System.out.println("RESULT.."+userRepo.findByusername(name.getUsername()));
//	   return userRepo.findByusername(name.getUsername());
//	 }
 
	  @PostMapping("")
      public String save(@RequestBody User user) {
	  userRepo.save(user); 
	  return user.getId();
	  }
	 
	 @PutMapping("/{id}")
	 public void updateUser(@PathVariable("id") ObjectId id, @RequestBody User user) {
		 User oldUser = userRepo.findByid(id);
		 oldUser.setPassword(user.getPassword());
		 oldUser.setUsername(user.getUsername());
		 oldUser.setRole(user.getRole());
		// oldUser.setUserType(user.getUserType());
		
		 userRepo.save(oldUser);
	 }
	 
@DeleteMapping("/{id}")
	 public void deleteUSer(@PathVariable("id") ObjectId id) {
		 userRepo.deleteById(id.toString());
}
	 
	 
		  

}
